# TP8

## Ejercicio 1

![tp8](TP8.1.png)

## Ejercicio 2

Como había mucha cantidad de aristas y vértices se adjuntan varias imágenes de la red formada.

### Imágenes

1. Vista inicial sin reordenamiento

![Vista inicial sin reordenamiento](TP8.2.1_vista_inicial.png)

2. Vista inicial con un subconjunto seleccionado

![Vista inicial con un subconjunto seleccionado](TP8.2.2_vista_inicial_subconjunto.png)

3. Vista global después de aplicar Atlas 2

![Vista global después de aplicar Atlas 2](TP8.2.3_force_atlas_global.png)

4. Vista del cluster central

![Vista del cluster central](TP8.2.4_force_atlas_cluster_central.png)

5. Vista de un triángulo en particular de ejemplo en cluster central

![Vista de un triángulo en particular de ejemplo en cluster central](TP8.2.5_force_atlas_cluster_central_triangulo_particular.png)
